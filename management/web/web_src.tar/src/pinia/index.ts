export const pinia = createPinia()
